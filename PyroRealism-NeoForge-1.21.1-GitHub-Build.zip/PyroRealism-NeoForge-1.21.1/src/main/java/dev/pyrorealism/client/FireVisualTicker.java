package dev.pyrorealism.client;

import dev.pyrorealism.PyroRealism;
import dev.pyrorealism.registry.PyroParticles;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CampfireBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

@EventBusSubscriber(modid = PyroRealism.MOD_ID, value = Dist.CLIENT)
public final class FireVisualTicker {
    private static int tickCounter;

    private FireVisualTicker() {}

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null || minecraft.player == null || minecraft.isPaused()) {
            return;
        }

        // Spawn in short batches to keep the visual effect inexpensive on large fires.
        if (++tickCounter % 5 != 0) {
            return;
        }

        var level = minecraft.level;
        BlockPos center = minecraft.player.blockPosition();
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
        int processed = 0;
        final int maxSourcesPerPass = 30;
        final int radius = 10;

        scan:
        for (int dy = -4; dy <= 6; dy++) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    cursor.set(center.getX() + dx, center.getY() + dy, center.getZ() + dz);
                    BlockState state = level.getBlockState(cursor);

                    boolean normalFire = state.is(Blocks.FIRE);
                    boolean soulFire = state.is(Blocks.SOUL_FIRE);
                    boolean campfire = (state.is(Blocks.CAMPFIRE) || state.is(Blocks.SOUL_CAMPFIRE))
                            && state.hasProperty(CampfireBlock.LIT) && state.getValue(CampfireBlock.LIT);
                    if (!normalFire && !soulFire && !campfire) {
                        continue;
                    }

                    processed++;
                    if (processed > maxSourcesPerPass) {
                        break scan;
                    }
                    spawnAt(level, cursor, soulFire, campfire);
                }
            }
        }
    }

    private static void spawnAt(net.minecraft.client.multiplayer.ClientLevel level, BlockPos pos,
                                boolean soulFire, boolean campfire) {
        var random = level.random;
        double x = pos.getX() + 0.22 + random.nextDouble() * 0.56;
        double y = pos.getY() + (campfire ? 0.42 : 0.18) + random.nextDouble() * 0.42;
        double z = pos.getZ() + 0.22 + random.nextDouble() * 0.56;
        double windX = (random.nextDouble() - 0.5) * 0.012;
        double windZ = (random.nextDouble() - 0.5) * 0.012;

        if (!campfire && random.nextFloat() < (soulFire ? 0.88F : 0.78F)) {
            level.addParticle(PyroParticles.FLAME.get(), x, y, z,
                    windX * 0.7, 0.006 + random.nextDouble() * 0.018, windZ * 0.7);
        }

        if (campfire) {
            if (random.nextFloat() < 0.96F) {
                level.addParticle(PyroParticles.SMOKE.get(), x, pos.getY() + 0.52 + random.nextDouble() * 0.12, z,
                        windX, 0.018 + random.nextDouble() * 0.018, windZ);
            }
        } else if (random.nextFloat() < 0.70F) {
            level.addParticle(PyroParticles.DARK_SMOKE.get(), x, y + 0.12, z,
                    windX, 0.008 + random.nextDouble() * 0.012, windZ);
        }

        if (!campfire && random.nextFloat() < (soulFire ? 0.10F : 0.075F)) {
            level.addParticle(PyroParticles.EMBER.get(), x, y, z,
                    windX * 2.2, 0.015 + random.nextDouble() * 0.025, windZ * 2.2);
        }

        // A small, pale upper wisp gives the plume depth without flooding the screen.
        if (random.nextFloat() < (campfire ? 0.42F : 0.24F)) {
            level.addParticle(PyroParticles.SMOKE.get(), x, y + 0.16, z,
                    windX * 0.8, 0.020 + random.nextDouble() * 0.018, windZ * 0.8);
        }
    }
}
